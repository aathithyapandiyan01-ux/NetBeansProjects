
package taxibookingmanagementsystem;

public interface Fare 
{
    void calculateFare();
    
}
