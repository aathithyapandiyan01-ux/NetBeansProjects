
package buildingconstructionmanagementsystem;


public interface ConstructionRules
{
    
    void calculateCost();
    
}
