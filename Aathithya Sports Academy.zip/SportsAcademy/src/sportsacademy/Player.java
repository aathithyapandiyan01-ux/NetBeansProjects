
package sportsacademy;
import java.util.Scanner;

public class Player extends Person implements AcademyRules
{
    Scanner sc = new Scanner(System.in);

    private String Sport ;

    public Player() {
        super();
        System.out.println("ENTER THE NAME OF THE PLAYER SPORTS ");
        this.Sport = sc.nextLine();
    }
    
    
    @Override
    public void followrules()
    {
        System.out.println("######PLAYER DETAILS######");
        System.out.println("NAME OF THE PLAYER :"+""+Name);
        System.out.println("AGE OF THE PLAYER :"+""+Age);
        System.out.println("SPORT HE IS PLAYING :"+""+Sport);
        System.out.println("THE PLAYER MUST ATTEND THE DAILY PRACTICE");
    
    
    
    }
    
    
    
}
