
 
package sportsacademy;


public interface AcademyRules
{
    void followrules();
    
}
