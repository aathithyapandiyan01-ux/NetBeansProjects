
package sportsacademy;
import java.util.Scanner;
public class Person
{
    Scanner sc = new Scanner(System.in);

    protected String Name ;
    protected int Age ;

    public Person()
    {
        System.out.println("ENTER THE NAME :");
        this.Name=sc.nextLine();
        System.out.println("ENTER THE AGE :");
        this.Age=sc.nextInt();
    }
    
    void display()
    {
        System.out.println("Name of the person :"+""+Name);
        System.out.println("Age of the person"+""+Age);
    
    }
    
    
}
