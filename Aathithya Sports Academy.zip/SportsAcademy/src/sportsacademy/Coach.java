
package sportsacademy;
import java.util.Scanner;

public class Coach extends Person implements AcademyRules
{
    Scanner sc = new Scanner(System.in);
    private String Specialization ;
    
    Coach()
    {
        super();
        System.out.println("ENTER THE NAME OF THE SPORTS, COACH IS TRAINING ");
        this.Specialization=sc.nextLine();
    
    }
    
    public void followrules()
    {
        System.out.println("######COACH DETAILS######");
        System.out.println("NAME OF THE COACH :"+""+Name);
        System.out.println("AGE OF THE COACH :"+""+Age);
        System.out.println("SPORT HE IS TEACHING :"+""+Specialization);
        System.out.println("THE COACH MUST TRAIN PLAYERS ON TIME  ");
    
    
    }
}
