
package sportsacademy;
import java.util.Scanner;
public class SportsAcademyMain {

  
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        
        int choice ;
        do
        {
            System.out.println(" 1 for set player details ");
            System.out.println(" 2 for set coach details ");
            System.out.println(" 3 for exit ");
            System.out.println(" enter ur choice");
            choice = sc.nextInt();
            
            switch(choice)
            {
                
                case 1 :
                {
                    Player p = new Player();
                    p.followrules();
                    break;
                
                
                }
                
                case 2 :
                {
                    Coach c = new Coach();
                    c.followrules();
                    break;
                
                
                }
                
                case 3 :
                {
                    System.out.println("Thank You , Exiting");break;
                
                }
            
   
            
            }
 
        
        }while(choice!=3);
        
    }
    
}
